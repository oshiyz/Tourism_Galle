import { Component } from '@angular/core';

@Component({
  selector: 'app-review-screen',
  imports: [],
  templateUrl: './review-screen.component.html',
  styleUrl: './review-screen.component.scss'
})
export class ReviewScreenComponent {

}
