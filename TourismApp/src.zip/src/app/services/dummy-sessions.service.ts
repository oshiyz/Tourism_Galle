import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root' // Makes the service a singleton, available app-wide
})

export class SessionService {
  private readonly EMAIL_KEY = 'current_email'; // Key for localStorage

  // Set the current user's email in localStorage
  setCurrentEmail(email: string): void {
    localStorage.setItem(this.EMAIL_KEY, email);
  }

  // Get the current user's email from localStorage
  getCurrentEmail(): string | null {
    return localStorage.getItem(this.EMAIL_KEY); // Returns null if key doesn't exist
  }

  // Clear the session by removing the email from localStorage
  clearSession(): void {
    localStorage.removeItem(this.EMAIL_KEY);
  }
  
}